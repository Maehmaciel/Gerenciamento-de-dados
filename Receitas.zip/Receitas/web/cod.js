 function criarAjax(recurso,funcao)
{
    let ajax=new XMLHttpRequest();
    ajax.onreadystatechange=funcao;
    ajax.open("GET",recurso,true);
    ajax.send();
}

  function mostrar()
{
    if(this.readyState==4&&this.status==200)
    {
        
        var doc=this.responseXML;
        var raiz=doc.documentElement;
        var texto=raiz;
        
        document.getElementById("conteudo").innerHTML=texto;
    }
}
  
  document.getElementById("resp").onload=function(){
    criarAjax("mostrarDados",mostrar);
}

