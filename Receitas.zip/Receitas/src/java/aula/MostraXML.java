/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula;

import java.io.IOException;
import java.io.PrintStream;
import java.io.Writer;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

public class MostraXML {
    Document doc;
    public MostraXML(String caminho)
    {
        try {
            DocumentBuilderFactory fabrica=DocumentBuilderFactory.newInstance();
            DocumentBuilder construtor=fabrica.newDocumentBuilder();
            doc=construtor.parse(caminho);
        } catch (SAXException | IOException | ParserConfigurationException ex) {
            Logger.getLogger(MostraXML.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public String pegaRaiz()
    {
        return doc.getDocumentElement().getNodeName();
    }
    public String pegaFilhos()
    {
        String texto="<article style='color:blue'>";
        Element raiz=doc.getDocumentElement();
        NodeList filhos=raiz.getChildNodes();
        int quant=filhos.getLength();
        for(int i=0;i<quant;i++)
        {
            if(filhos.item(i).getNodeType()==Node.ELEMENT_NODE)
            {
                texto+="<p><b>"+filhos.item(i).getNodeName()+":</b> ";
                texto+=filhos.item(i).getFirstChild().getNodeValue()+"</p>\n";
            }
        }
        texto+="</article>";
        return texto;
    }
    public String pegaAtributosDaRaiz()
    {
        String texto="";
        Element raiz=doc.getDocumentElement();
        NamedNodeMap atributos=raiz.getAttributes();
        int quant=atributos.getLength();
        for(int i=0;i<quant;i++)
        {
            texto+="<p><b>"+atributos.item(i).getNodeName()+":</b> ";
            texto+=atributos.item(i).getNodeValue()+"</p>";
        }
        return texto;
    }
    public void criaData()
    {
        Element data=doc.createElement("data");
        Text texto=doc.createTextNode("26-09-2019");
        data.appendChild(texto);
        Element raiz=doc.getDocumentElement();
        //raiz.appendChild(data);
        Node filho1=raiz.getFirstChild();
        
        raiz.insertBefore(data,filho1);
    }
    public void serealizar(PrintStream out)
    {
        try {
            TransformerFactory fabrica=TransformerFactory.newInstance();
            Transformer transformador=fabrica.newTransformer();
            DOMSource fonte=new DOMSource(doc);
            StreamResult saida=new StreamResult(out);
            transformador.transform(fonte, saida);
        } catch (TransformerException ex) {
            Logger.getLogger(MostraXML.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void serealizar(Writer out)
    {
        try {
            TransformerFactory fabrica=TransformerFactory.newInstance();
            Transformer transformador=fabrica.newTransformer();
            DOMSource fonte=new DOMSource(doc);
            StreamResult saida=new StreamResult(out);
            transformador.transform(fonte, saida);
        } catch (TransformerException ex) {
            Logger.getLogger(MostraXML.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    /* public String pegaReceitas()
    {   ArrayList<Node> receita=new ArrayList();
        String texto="<article style='color:blue'>";
        Element raiz=doc.getDocumentElement();
        NodeList receitas=raiz.getElementsByTagName("receita");
        
        int quant=receitas.getLength();
        for(int i=0;i<quant;i++)
        {
            if(receitas.item(i).getNodeType()==Node.ELEMENT_NODE)
            {
               NodeList uRec= receitas.item(i).getChildNodes();
                for(int j=0;j<uRec.getLength();j++){
                    if(uRec.item(j).getNodeType()==Node.ELEMENT_NODE && uRec.item(j).getNodeName().equalsIgnoreCase("nome") ){
                    texto+=uRec.item(j).getFirstChild().getNodeValue()+"<br>";
                    }
                }
            }
        }
        texto+="</article>";
        return texto;
    }*/
    
     public String pegaReceitas()
    {  
        String texto="";
        Element raiz=doc.getDocumentElement();
        NodeList receitas=raiz.getElementsByTagName("nome");
        int quant=receitas.getLength();
        for(int i=0;i<quant;i++)
        {
            texto+=receitas.item(i).getFirstChild().getNodeValue()+",";
        }
        return texto;
    }
    public static void main(String[] args) {
        MostraXML mostrador=new MostraXML("src/java/aula/receitas.xml");
        mostrador.criaData();
        //System.out.println(mostrador.pegaRaiz());
        //System.out.println();
        //System.out.println(mostrador.pegaFilhos());
        mostrador.serealizar(System.out);
    }
}
